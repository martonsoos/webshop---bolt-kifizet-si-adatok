import { Controller, Get, Post, Render, Body } from '@nestjs/common';

@Controller()
export class AppController {   
  }
  
    @Get('payment')
    @Render('payment')
    getPayment() {
        return { errors: [] }; // Kezdeti üres hiba lista
    }

    @Post('payment')
    @Render('payment')
    handlePayment(@Body() body: any) {
        const { name, bankAccount, termsAccepted } = body;
        const errors: string[] = [];

        if (!name || name.trim().length < 1) {
            errors.push('A név megadása kötelező.');
        }

        const bankAccountRegex1 = /^\d{8}-\d{8}$/; 
        const bankAccountRegex2 = /^\d{8}-\d{8}-\d{8}$/;

        if (!bankAccount || (!bankAccountRegex1.test(bankAccount) && !bankAccountRegex2.test(bankAccount))) {
            errors.push('Helytelen bankszámlaszám formátum.');
        }

        if (!termsAccepted) {
            errors.push('El kell fogadnia a szerződési feltételeket.');
        }

        return { errors };
    }
}
