import { NestFactory } from '@nestjs/core';
import { AppModule } from './app.module';

async function bootstrap() {
    const app = await NestFactory.create(AppModule);
    app.setViewEngine('ejs');
    app.useStaticAssets('views'); // statikus fájlok (pl. CSS) elérhetősége
    await app.listen(3000);
}
bootstrap();
